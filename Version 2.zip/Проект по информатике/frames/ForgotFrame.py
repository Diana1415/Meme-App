"""This module runs forgot password page."""


from customtkinter import CTkFrame, CTkEntry, CTkLabel, CTkButton

class ForgotFrame(CTkFrame):
    """Log In Page."""

    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Configure grid to expand
        self.pack(fill="both", expand=True)

        # Title
        self.title1 = CTkLabel(self, text="Type your email", font=("Arial", 24, "bold"))
        self.title1.pack(pady=10)

        # Email Entry
        self.email_entry = CTkEntry(self, placeholder_text="Username")
        self.email_entry.pack(pady=5)

        # Submit Button
        CTkButton(self, text="Send reset password link", command=self.recovery).pack(pady=10)


        # Back button
        import frames.LoginFrame as lf
        CTkButton(self, text="Back", command=lambda: controller.show_frame(lf.LoginFrame)).pack(pady=5)

    def recovery(self):
        pass