"""This module applies twist to the image."""


import cv2
import numpy as np
from PIL import Image, ImageFilter


def twist_image(image_array, strength, cx, cy, radius):

    img = image_array
    h, w = img.shape[:2]
    strength = strength/25

    # Создаём координатную сетку
    y, x = np.indices((h, w), dtype=np.float32)

    # Переводим в полярные координаты (r, θ)
    dx, dy = x - cx, y - cy
    r = np.sqrt(dx**2 + dy**2)
    
    r[r == 0] = 1e-6
    mask = (r <= radius).astype(np.float32)

    theta = np.arctan2(dy, dx)
    # Добавляем эффект скручивания (чем дальше от центра, тем больше поворот)
    twist_strength = mask * strength * (1 - r / radius)  # Больше у центра, меньше на краях
    theta += twist_strength

    # Переводим обратно в (x, y)
    x_new = cx + r * np.cos(theta)
    y_new = cy + r * np.sin(theta)

    # Делаем map для cv2.remap()
    map_x = np.clip(x_new, 0, w - 1).astype(np.float32)
    map_y = np.clip(y_new, 0, h - 1).astype(np.float32)

    # Применяем трансформацию
    twisted_img = cv2.remap(img, map_x, map_y, interpolation=cv2.INTER_LINEAR)

    return twisted_img

