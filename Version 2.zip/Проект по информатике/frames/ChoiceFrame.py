"""This module runs login page."""


from customtkinter import CTkFrame, CTkEntry, CTkLabel, CTkButton
import customtkinter as ctk
from frames.CreateFrame import CreateFrame
from frames.DistortFrame import DistortFrame


class ChoiceFrame(CTkFrame):
    """Log In Page."""

    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Configure grid to expand
        self.pack(fill="both", expand=True)

        # Title
        self.title1 = CTkLabel(self, text="", font=("Arial", 24, "bold"))
        self.title1.pack(pady=10)


        # Create Account Button (используем controller.frames)
        import frames.SignupFrame as sf
        CTkButton(self, text="Distort Image", command=lambda: controller.show_frame(DistortFrame)).pack(pady=5)

        # Forgot password Button (используем controller.frames)
        import frames.ForgotFrame as ff
        CTkButton(self, text="Create Image", command=lambda: controller.show_frame(CreateFrame)).pack(pady=5)

