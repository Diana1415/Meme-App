import cv2
import numpy as np
from PIL import Image, ImageFilter


def wave_distortion(image, valuex, valuey, img_h, img_w):
    """ Волновое искажение """
    valuex = int(valuex)
    valuey = int(valuey)
    img = np.float32(image)

    # Генерация волны по оси X
    for i in range(img_h):
        shift_x = int(valuex * np.sin(2 * np.pi * i / 64))
        img[i] = np.roll(img[i], shift_x, axis=0)

    # Генерация волны по оси Y
    for j in range(img_w):
        shift_y = int(valuey * np.sin(2 * np.pi * j / 64))
        img[:, j] = np.roll(img[:, j], shift_y, axis=0)

    image = np.uint8(img)
    return image