import cv2
import random
import numpy as np

def glitch_image(image, strength):
    """ Смещение цветовых каналов """
    img_array = np.array(image, dtype=np.uint8)  # Преобразуем PIL в numpy

    # Проверяем количество каналов
    if len(img_array.shape) == 2:  # Если изображение ч/б (grayscale), преобразуем в BGR
        img_array = cv2.cvtColor(img_array, cv2.COLOR_GRAY2BGR)
    elif img_array.shape[2] == 4:  # Если изображение RGBA, удаляем альфа-канал
        img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2BGR)

    b, g, r = cv2.split(img_array)  # Теперь точно 3 канала
    shift = int(strength)

    shift_x = shift % img_array.shape[1]
    shift_y = shift % img_array.shape[0]
    
    # Смещение цветовых каналов
    b = np.roll(b, shift_x, axis=1)
    g = np.roll(g, -shift_y, axis=0)


    glitched_image = cv2.merge([b, g, r])  # Объединяем обратно в BGR
    glitched_image = np.clip(glitched_image, 0, 255).astype(np.uint8)
    return glitched_image