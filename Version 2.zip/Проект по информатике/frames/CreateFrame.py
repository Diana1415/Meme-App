from tkinter import *
from tkinter import filedialog, colorchooser
from PIL import Image, ImageDraw, ImageFont, ImageTk, ImageFilter
import customtkinter as ctk
import cv2
import numpy as np

class CreateFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Image
        self.img = None  # Исходное изображение
        self.tk_img = None  # Версия для отображения

        # Text
        self.text_id = None  # ID текста на canvas
        self.text_var = StringVar()
        self.text_x, self.text_y = 200, 200
        self.angle = 0  # Угол поворота текста
        self.size = 1.0  # Масштаб текста
        self.drag_data = {"x": 0, "y": 0}
        self.font = "Arial"
        self.color = "black"

        # === Центральная часть (Canvas) ===
        self.canvas = Canvas(self, width=400, height=400, bg="white")
        self.canvas.pack(side="left", expand=1, fill="both")
        # "No Image Uploaded" text
        self.text_placeholder = self.canvas.create_text(
                100, 100,  # Координаты (по центру Canvas)
                text="No Image Uploaded", 
                font=("Helvetica", 12), 
                fill="black"
                )
        self.canvas.bind("<Configure>", self.center_text)

        self.canvas.bind("<ButtonPress-1>", self.on_text_press)
        self.canvas.bind("<B1-Motion>", self.on_text_drag)

        # === Правая панель инструментов ===
        self.right_panel = ctk.CTkFrame(self, width=600)
        self.right_panel.pack(side="left", fill="y", padx=5, pady=5)


        ctk.CTkLabel(self.right_panel, text="Text & Filters", font=("Helvetica", 12)).pack(pady=5)
        self.text_entry = ctk.CTkEntry(self.right_panel, textvariable=self.text_var, width=120, placeholder_text="Enter text")
        self.text_entry.pack(pady=5)

        self.add_text_button = ctk.CTkButton(self.right_panel, text="Add Text", command=self.add_text)
        self.add_text_button.pack(pady=5)

        self.fonts_frame = ctk.CTkFrame(self.right_panel)
        self.fonts_frame.pack(padx=5, fill='x')
        ctk.CTkLabel(self.fonts_frame, text="Fonts", font=("Helvetica", 14)).pack(anchor='nw')
        self.fonts = ctk.CTkComboBox(self.fonts_frame, values=["Arial", "Times New Roman", "Courier New"], command=self.update_text_font)
        self.fonts.pack(pady=5)
        self.fonts.set("Arial")  # Устанавливаем шрифт по умолчанию


        self.change_color_frame = ctk.CTkFrame(self.right_panel)
        self.change_color_frame.pack(padx=5, pady=5)
        ctk.CTkLabel(self.change_color_frame, text="Text color", font=("Helvetica", 14)).pack(anchor='nw')
        self.text_color = ctk.CTkButton(self.change_color_frame,  text="Change Color", command=self.text_color)
        self.text_color.pack(side='right', padx=3)
        self.color_display = ctk.CTkLabel(self.change_color_frame, text="", width=20, height=20, fg_color="black", corner_radius=20)
        self.color_display.pack(side='left', padx=3)

        # === FONT SIZE CHANGE ===
        self.font_size_frame = ctk.CTkFrame(self.right_panel)
        self.font_size_frame.pack(padx=5, fill='x')
        ctk.CTkLabel(self.font_size_frame, text="Font size", font=("Helvetica", 14)).pack(anchor='nw')
        self.sizes = ctk.CTkComboBox(self.font_size_frame, values=['2', '4', '6', '8', '10', '12', '14', '16', '18', '20', '22', '24', '26'], command=self.text_size)
        self.sizes.pack(pady=5)
        self.sizes.set('10')

        # === LOAD, SAVE, CLEAR BUTTONS
        self.load_button = ctk.CTkButton(self.right_panel, text="Upload Image", command=self.load_image)
        self.load_button.pack(pady=5)

        self.save_button = ctk.CTkButton(self.right_panel, text="Save Meme", command=self.save_meme, state=DISABLED)
        self.save_button.pack(pady=5)

        self.clear_button = ctk.CTkButton(self.right_panel, text="Clear", command=self.clear_canvas)
        self.clear_button.pack(pady=5)

    # === Функции загрузки и отображения изображения ===
    def load_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg")])
        if not file_path:
            return

        self.img = Image.open(file_path)  # открываем изображение
        canvas_width = self.canvas.winfo_width()  # размеры канваса для растягивания изображения
        canvas_height = self.canvas.winfo_height()

        self.img = self.img.resize((canvas_width, canvas_height), Image.Resampling.LANCZOS)  # Изменение размеров изображения
        self.tk_img = ImageTk.PhotoImage(self.img)  # отображаемое изображение
        self.canvas.create_image(0, 0, anchor=NW, image=self.tk_img)  # открываем изображение
        
        self.save_button.configure(state=NORMAL)

    # === Функции текста ===
    def add_text(self):  # Text update function
        if not self.img:
            return
        if self.text_id:
            self.canvas.delete(self.text_id)
        text = self.text_var.get()
        self.text_id = self.canvas.create_text(self.text_x, self.text_y, text=text, font=(self.font, int(20 * self.size)), fill=self.color)


    def text_changed(self):
        if self.text_id:
            pass


    def on_text_press(self, event):
        """Фиксируем начальные координаты текста при клике."""
        if self.text_id and self.canvas.find_withtag("current"):
            self.drag_data["x"] = event.x
            self.drag_data["y"] = event.y


    def on_text_drag(self, event):
        """Перемещаем текст при движении мыши."""
        dx = event.x - self.drag_data["x"]
        dy = event.y - self.drag_data["y"]
        self.canvas.move(self.text_id, dx, dy)
        self.drag_data["x"] = event.x
        self.drag_data["y"] = event.y
        self.text_x = event.x
        self.text_y = event.y


    def text_size(self, choice):  # text font size change   
        self.size = int(int(choice)/10*2)
        self.add_text()


    def text_color(self):
        """Меняет цвет текста"""
        color = colorchooser.askcolor()[1]
        if color:
            self.color = color
            self.color_display.configure(fg_color=color)
            self.add_text()


    def update_text_font(self, choice):
        self.font = choice
        self.add_text()


    def clear_canvas(self):
        self.canvas.delete("all")
        self.img = None
        self.save_button.configure(state=DISABLED)


    def apply_filter(self):
        """Применяет эффект размытия."""
        if not self.img:
            return
        img_array = np.array(self.img)
        img_array = cv2.GaussianBlur(img_array, (15, 15), 0)
        img_filtered = Image.fromarray(img_array)
        self.tk_img = ImageTk.PhotoImage(img_filtered)
        self.canvas.create_image(0, 0, anchor=NW, image=self.tk_img)
        self.img = img_filtered


    def save_meme(self):
        """Сохраняет изображение с текстом и фильтрами."""
        if not self.img:
            return
        img_with_text = self.img.copy()
        draw = ImageDraw.Draw(img_with_text)

        try:
            font = ImageFont.truetype("arial.ttf", 30)
        except IOError:
            font = ImageFont.load_default()

        text = self.text_var.get()
        draw.text((self.text_x, self.text_y), text, font=font, fill="white")

        save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg")])
        if save_path:
            img_with_text.save(save_path)


    def center_text(self, event):  # Centers "No Image Uploaded" text
        """Обновляет позицию текста при изменении размеров Canvas."""
        self.canvas.coords(self.text_placeholder, event.width // 2, event.height // 2)
