import cv2
import numpy as np
from PIL import Image, ImageFilter
import random


def perspective_warp(image, valuex, valuey, img_w, img_h):
    """ Перспективное искажение """
    valuex = float(valuex) * 0.01 * img_w
    valuey = float(valuey) * 0.01 * img_h

    pts1 = np.float32([[0, 0], [img_w, 0], [0, img_h], [img_w, img_h]])
    # Новые точки с учетом перспективного искажения
    pts2 = np.float32([
        [0 + valuex, 0 ],                       # Левый верхний угол
        [img_w - valuex, 0 ],                    # Правый верхний угол
        [0 - valuex, img_h],                    # Левый нижний угол
        [img_w + valuex, img_h]                 # Правый нижний угол
    ])
    matrix = cv2.getPerspectiveTransform(pts1, pts2)
    pts3 = np.float32([
        [0, 0 + valuey ],                       # Левый верхний угол
        [img_w, 0 - valuey],                    # Правый верхний угол
        [0, img_h - valuey],                    # Левый нижний угол
        [img_w, img_h + valuey]                 # Правый нижний угол
    ])
    matrix = cv2.getPerspectiveTransform(pts2, pts3)
    image = cv2.warpPerspective(image, matrix, (img_w, img_h))
    return image
