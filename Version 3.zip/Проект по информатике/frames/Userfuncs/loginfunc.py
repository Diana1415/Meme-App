from pymongo import MongoClient
import hashlib

connectionstring = "mongodb+srv://dianabikbulatoff:67rA0laKyDL3l1EW@cluster0.dgejj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

client = MongoClient(connectionstring)

database = client.get_database("sample_mflix")

users = database.get_collection("users")

def verify(username, password):
    return True
    sha256_username = hashlib.sha256()  # registering an object
    sha256_username.update(username.encode())  # hashing username
    crypted_username = sha256_username.hexdigest()
    query = {"username": crypted_username}
    user = users.find_one(query)  # searching if exists

    if user is None:
        return False

    sha256_password = hashlib.sha256()  # registering an object
    sha256_password.update(password.encode())  # hashing password
    crypted_password = sha256_password.hexdigest()

    if user["password"] == crypted_password:
        return True
    
def change(username, newusername, newpassword):
    #  How to keep reference to the previous username and password?

    sha256_username = hashlib.sha256()  # registering an object
    sha256_username.update(username.encode())  # hashing username
    crypted_username = sha256_username.hexdigest()

    sha256_newusername = hashlib.sha256()  # registering an object
    sha256_newusername.update(newusername.encode())  # hashing username
    crypted_newusername = sha256_newusername.hexdigest()

    sha256_newpassword = hashlib.sha256()  # registering an object
    sha256_newpassword.update(newpassword.encode())  # hashing username
    crypted_newpassword = sha256_newpassword.hexdigest()

    filter = {"username":crypted_username}
    update_operation = {'$set': {'password': crypted_newpassword}}
    users.update_one(filter, update_operation)
    update_operation = {'$set': {'username': crypted_newusername}}
    users.update_one(filter, update_operation)

def close_conncetion():
    client.close()
