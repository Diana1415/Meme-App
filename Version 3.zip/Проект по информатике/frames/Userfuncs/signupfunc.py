from pymongo import MongoClient
import hashlib

connectionstring = "mongodb+srv://dianabikbulatoff:67rA0laKyDL3l1EW@cluster0.dgejj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

client = MongoClient(connectionstring)

database = client.get_database("sample_mflix")

users = database.get_collection("users")

def create(username, password):
    sha256_username = hashlib.sha256()  # registering an object
    sha256_username.update(username.encode())  # hashing username
    crypted_username = sha256_username.hexdigest()
    query = {"username": crypted_username}
    user = users.find_one(query)  # searching if exists

    if user is not None:
        print("This username already exists.\nTry again!")
        return False

    sha256_password = hashlib.sha256()  # registering an object
    sha256_password.update(password.encode())  # hashing password
    crypted_password = sha256_password.hexdigest()     
    newuser = {"username":crypted_username,
           "password":crypted_password}  # creating new user
    users.insert_one(newuser)
    print("Gratz! Successful Registration!")

    return True

def close_connection():
    client.close()
