from tkinter import *
from tkinter import filedialog, colorchooser
from PIL import Image, ImageDraw, ImageFont, ImageTk, ImageFilter
import customtkinter as ctk
from .Effects import twist, glitch, wave, perspective, distortion
import numpy as np
from PIL import Image, ImageTk
from math import sqrt

class DistortFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller


        # IMAGE VARIABLES
        self.img = None  # Исходное изображение
        self.img_org = None # Original version of image
        self.tk_img = None  # Версия для отображения
        self.photo_id = None  # ID изображения на canvas
        self.file_path = None # путь к изображению...
        self.curr_img = None
        self.cx = 300
        self.cy = 300


        # RIGHT PANEL
        self.left_panel = ctk.CTkFrame(self, width=50)
        self.left_panel.pack(side="left", fill='both', expand=True, padx=5, pady=5)

        # MIDDLE PANEL (FOR CANVAS)
        self.middel_panel = ctk.CTkFrame(self, width=200)
        self.middel_panel.pack(side='left')

        self.canvas = Canvas(self.middel_panel, width=900, height=900, bg="white")
        self.canvas.pack(side="top", expand=True, fill="both")

        # "No Image Uploaded" text
        self.text_placeholder = self.canvas.create_text(
                100, 100,  # Координаты (по центру Canvas)
                text="No Image Uploaded", 
                font=("Helvetica", 12), 
                fill="black"
                )
        self.canvas.bind("<Configure>", self.center_text)

        # === BOTTOM PANEL ===
        self.bottom_panel = ctk.CTkFrame(self.middel_panel, width=200)
        self.bottom_panel.pack(side='bottom', fill='both', expand=True)

        # === RIGHT PANEL ===
        self.right_panel = ctk.CTkFrame(self, width=50)
        self.right_panel.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        # === BOTTOM PANEL BUTTONS ===
        self.delete_button = ctk.CTkButton(self.bottom_panel, text='Delete Image', command=self.clear_canvas)
        self.delete_button.pack(side='right', pady=5)

        self.clear_button = ctk.CTkButton(self.bottom_panel, text='Clear Effetcs', command=self.clear_effects)
        self.clear_button.pack(side='left', pady=5)



        # === RIGHT INSTRUMENT PANEL ===
        self.upload_button = ctk.CTkButton(self.right_panel, text='Upload Image', command=self.load_image)
        self.upload_button.pack( pady=10)

        self.save_button = ctk.CTkButton(self.right_panel, text='Save Image', command=self.save_image)
        self.save_button.pack(pady=10)

        # Back button
        from frames.ChoiceFrame import ChoiceFrame
        ctk.CTkButton(self.right_panel, text="Back", command=lambda: controller.show_frame(ChoiceFrame)).pack(pady=5)


        #  !! LEFT INSTRUMENT PANEL !!
        self.rad_var = ctk.StringVar(value="apply_wave")


        # === WAVE EFFECT PANEL ===
        self.frame_1 = ctk.CTkFrame(self.left_panel)
        self.frame_1.pack(pady=5)
        ctk.CTkLabel(self.frame_1, text='Wave effect').pack(anchor='nw', pady=10)
        self.wave_btn = ctk.CTkRadioButton(self.frame_1, text='', value="apply_wave", variable=self.rad_var, command = self.switch_effects)  # RadioButton!! 
        self.wave_btn.pack(side='left', pady=10)
        self.wavex_slide = ctk.CTkSlider(self.frame_1, from_=-50, to=50, command=lambda value: self.apply_wave())
        self.wavex_slide.pack(anchor='ne', pady=10)
        self.wavey_slide = ctk.CTkSlider(self.frame_1, from_=-50, to=50, command=lambda value: self.apply_wave())
        self.wavey_slide.pack(anchor='se', pady=10)

        # === TWIST EFFECT PANEL ===
        self.frame_2 = ctk.CTkFrame(self.left_panel)
        self.frame_2.pack(pady=5)
        ctk.CTkLabel(self.frame_2, text='Twirl effect').pack(anchor='nw',pady=10)
        self.twist_btn = ctk.CTkRadioButton(self.frame_2, text='', value="apply_twist", variable=self.rad_var, command = self.switch_effects)
        self.twist_btn.pack(side='left', pady=10)
        self.twist_strength_slide = ctk.CTkSlider(self.frame_2, from_=-100, to=100, command=lambda value: self.apply_twist())
        self.twist_strength_slide.pack(anchor='ne', pady=5)
        self.twist_radius_slide = ctk.CTkSlider(self.frame_2, from_=1, to=100, command=lambda value: self.apply_twist())
        self.twist_radius_slide.pack(anchor='se', pady=5)

        # === GLITCH EFFECT PANEL
        self.frame_3 = ctk.CTkFrame(self.left_panel)
        self.frame_3.pack(pady=5)
        ctk.CTkLabel(self.frame_3, text='Glitch effect').pack(anchor='nw', pady=10)
        self.glitch_btn = ctk.CTkRadioButton(self.frame_3, text='', value="apply_glitch", variable=self.rad_var, command = self.switch_effects)
        self.glitch_btn.pack(side='left', pady=10)
        self.glitch_slide = ctk.CTkSlider(self.frame_3, from_=-50, to=50, command=self.apply_glitch)
        self.glitch_slide.pack(side='right', pady=5)

        # === PERSPECTIVE EFFECT PANEL
        self.frame_4 = ctk.CTkFrame(self.left_panel)
        self.frame_4.pack(pady=5)
        ctk.CTkLabel(self.frame_4, text='Perspective effect').pack(anchor='nw',pady=10)
        self.pers_btn = ctk.CTkRadioButton(self.frame_4, text='', value="apply_pers", variable=self.rad_var, command = self.switch_effects)
        self.pers_btn.pack(side='left', pady=10)
        self.perspectivex_slide = ctk.CTkSlider(self.frame_4, from_=-100, to=100, command=lambda value: self.apply_perspective())
        self.perspectivex_slide.pack(anchor='ne', pady=5)
        self.perspectivey_slide = ctk.CTkSlider(self.frame_4, from_=-100, to=100, command=lambda value: self.apply_perspective())
        self.perspectivey_slide.pack(anchor='se', pady=5)

        # === DISTORTION 1 PANEL ===
        self.frame_5 = ctk.CTkFrame(self.left_panel)
        self.frame_5.pack(pady=5)
        ctk.CTkLabel(self.frame_5, text='Complete Distortion').pack(anchor='nw',pady=10)
        self.distortion_btn = ctk.CTkRadioButton(self.frame_5, text='', value="apply_dist", variable=self.rad_var, command = self.switch_effects)
        self.distortion_btn.pack(side='left', pady=10)
        self.distortion_strength_slide = ctk.CTkSlider(self.frame_5, from_=-100, to=100, command=lambda value: self.apply_distortion())
        self.distortion_strength_slide.pack(anchor='ne', pady=5)
        self.distortion_radius_slide = ctk.CTkSlider(self.frame_5, from_=0, to=100, command=lambda value: self.apply_distortion())
        self.distortion_radius_slide.pack(anchor='se', pady=5)


        # Привязка событий к canvas
        self.canvas.bind("<Button-1>", self.start_drag)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.stop_drag)


        self.switch_effects()
        self.disable_sliders()


    def start_drag(self, event):
        # Проверяем, выбран ли эффект twist
        if self.rad_var.get() == "apply_twist" or self.rad_var.get() == "apply_dist":
            self.dragging = True
            self.update_twist_center(event)


    def on_drag(self, event):
        # Обновляем центр twist при перемещении мыши
        if self.dragging and self.rad_var.get() == "apply_twist":
            self.update_twist_center(event)
            self.apply_twist()

        if self.dragging and self.rad_var.get() == "apply_dist":
            self.update_twist_center(event)
            self.apply_distortion()


    def update_twist_center(self, event):
        # Пересчёт координат эпицентра
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()

        img_w, img_h = self.img.size
        self.cx = int(event.x * (img_w / canvas_w))
        self.cy = int(event.y * (img_h / canvas_h))


    def stop_drag(self, event):
        # Прекращаем перемещение
        self.dragging = False


    def load_image(self):  # Uploads image on canvas
        if self.photo_id:
            return
        self.file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg")])
        if not self.file_path:
            return

        self.img = Image.open(self.file_path)  # открываем изображение
        self.img_org = Image.open(self.file_path)
        canvas_width = self.canvas.winfo_width()  # размеры канваса для растягивания изображения
        canvas_height = self.canvas.winfo_height()

        self.img = self.img.resize((canvas_width, canvas_height), Image.Resampling.LANCZOS)  # Изменение размеров изображения
        self.tk_img = ImageTk.PhotoImage(self.img)  # отображаемое изображение
        self.photo_id = self.canvas.create_image(0, 0, anchor=NW, image=self.tk_img)  # открываем изображение
        self.canvas.itemconfig(self.text_placeholder, text='')

        self.save_button.configure(state=NORMAL)
        self.switch_effects()


    def clear_canvas(self):  # Clears canvas from image
        self.canvas.delete(self.photo_id)
        self.img = None  # Исходное изображение
        self.img_org = None # Original version of image
        self.tk_img = None  # Версия для отображения
        self.photo_id = None  # ID изображения на canvas
        self.file_path = None # путь к изображению...
        self.curr_img = None
        self.save_button.configure(state=DISABLED)
        self.canvas.itemconfig(self.text_placeholder, text='No Image Uploaded')
        self.rad_var = ctk.StringVar(value="apply_wave")
        self.reset_sliders()
        self.switch_effects()
        self.disable_sliders()


    def clear_effects(self):  # Clears effects
        canvas_width = self.canvas.winfo_width()  # размеры канваса для растягивания изображения
        canvas_height = self.canvas.winfo_height()

        self.img = self.img_org.resize((canvas_width, canvas_height), Image.Resampling.LANCZOS)  # Изменение размеров изображения
        self.curr_img = None

        self.tk_img = ImageTk.PhotoImage(self.img)  # отображаемое изображение
        self.canvas.itemconfig(self.photo_id, image=self.tk_img)
        self.reset_sliders()


    def save_image(self):  # Saves final image
        """Сохраняет изображение с текстом и фильтрами."""
        if not self.img:
            return
        save_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg")])
        if save_path:
            self.curr_img.save(save_path)


    def center_text(self, event):  # Centers "No Image Uploaded" text
        """Обновляет позицию текста при изменении размеров Canvas."""
        self.canvas.coords(self.text_placeholder, event.width // 2, event.height // 2)


    def apply_twist(self):  # Handles twist effect application
        if self.img is None:
            return
    
        img_array = np.array(self.img)  # Преобразуем PIL Image в numpy array

        img_w, img_h = self.img.size
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
    
        cx = int(self.cx * (img_w / canvas_w))
        cy = int(self.cy * (img_h / canvas_h))

        value = self.twist_strength_slide.get()
        radius = sqrt((float(img_w)/2)**2+(float(img_h)/2)**2)*int(self.twist_radius_slide.get())*0.01

        # Обрабатываем изображение через функцию twist_image
        twisted_img_array = twist.twist_image(img_array, value, cx, cy, radius)

        # Преобразуем обратно в PIL Image
        twisted_img = Image.fromarray(twisted_img_array)

        # Обновляем canvas
        self.tk_img = ImageTk.PhotoImage(twisted_img)
        self.curr_img = Image.fromarray(twisted_img_array)
        # self.img = self.tk_img
        self.canvas.itemconfig(self.photo_id, image=self.tk_img)


    def apply_distortion(self):  # Handles twist effect application
        if self.img is None:
            return
    
        img_array = np.array(self.img)  # Преобразуем PIL Image в numpy array

        img_w, img_h = self.img.size
        canvas_w = self.canvas.winfo_width()
        canvas_h = self.canvas.winfo_height()
    
        cx = int(self.cx * (img_w / canvas_w))
        cy = int(self.cy * (img_h / canvas_h))

        value = self.distortion_strength_slide.get()*50
        radius = sqrt((float(img_w)/2)**2+(float(img_h)/2)**2)*int(self.distortion_radius_slide.get())*0.01

        # Обрабатываем изображение через функцию twist_image
        distorted_img_array = distortion.distort_face(img_array, cx, cy, value, radius)

        # Преобразуем обратно в PIL Image
        distorted_img = Image.fromarray(distorted_img_array)

        # Обновляем canvas
        self.tk_img = ImageTk.PhotoImage(distorted_img)
        self.curr_img = Image.fromarray(distorted_img_array)
        # self.img = self.tk_img
        self.canvas.itemconfig(self.photo_id, image=self.tk_img)


    def apply_glitch(self, value):  # Handles glitch effect application
        if self.img is None:
            return
        glitched_img_array = glitch.glitch_image(self.img, int(value))

        glitched_img = Image.fromarray(glitched_img_array)

        # Обновляем canvas
        self.tk_img = ImageTk.PhotoImage(glitched_img)
        self.curr_img = Image.fromarray(glitched_img_array)

        self.canvas.itemconfig(self.photo_id, image=self.tk_img)


    def apply_perspective(self):  # Handles pers effect application
        if self.img is None:
            return

        img_w, img_h = self.img.size
        img_array = np.array(self.img)  # Преобразуем PIL Image в numpy array

        valuex = self.perspectivex_slide.get()
        valuey = self.perspectivey_slide.get()

        # Обрабатываем изображение через функцию twist_image
        pers_img_array = perspective.perspective_warp(img_array, valuex, valuey, img_w, img_h)

        # Преобразуем обратно в PIL Image
        pers_img = Image.fromarray(pers_img_array)


        # Обновляем canvas
        self.tk_img = ImageTk.PhotoImage(pers_img)
        self.curr_img = Image.fromarray(pers_img_array)

        self.canvas.itemconfig(self.photo_id, image=self.tk_img)


    def apply_wave(self):  # Handles wave effect application
        if self.img is None:
            return

        img_w, img_h = self.img.size
        img_array = np.array(self.img)  # Преобразуем PIL Image в numpy array
        valuex = self.wavex_slide.get()
        valuey = self.wavey_slide.get()

        # Обрабатываем изображение через функцию twist_image
        wave_img_array = wave.wave_distortion(img_array, valuex, valuey, img_h, img_w)

        # Преобразуем обратно в PIL Image
        wave_img = Image.fromarray(wave_img_array)

        # Обновляем canvas
        self.tk_img = ImageTk.PhotoImage(wave_img)
        self.curr_img = Image.fromarray(wave_img_array)
    
        self.canvas.itemconfig(self.photo_id, image=self.tk_img)


    def reset_sliders(self):
        # Сбрасываем слайдеры к начальным значениям
        self.wavex_slide.set(0)
        self.wavey_slide.set(0)
        self.twist_strength_slide.set(0)
        self.twist_radius_slide.set(50)
        self.glitch_slide.set(0)
        self.perspectivex_slide.set(0)
        self.perspectivey_slide.set(0)


    def switch_effects(self):
        if self.curr_img:
            self.img = self.curr_img
        
        # Получаем текущее значение radio button
        effect = self.wave_btn.cget('variable').get()

        # Отключаем все слайдеры
        self.wavex_slide.configure(state='disabled')
        self.wavey_slide.configure(state='disabled')
        self.twist_strength_slide.configure(state='disabled')
        self.twist_radius_slide.configure(state='disabled')
        self.glitch_slide.configure(state='disabled')
        self.perspectivex_slide.configure(state='disabled')
        self.perspectivey_slide.configure(state='disabled')
        self.distortion_radius_slide.configure(state='disabled')
        self.distortion_strength_slide.configure(state='disabled')

        # Включаем нужные слайдеры
        if effect == "apply_wave":
            self.wavex_slide.configure(state='normal')
            self.wavey_slide.configure(state='normal')
        elif effect == "apply_twist":
            self.twist_strength_slide.configure(state='normal')
            self.twist_radius_slide.configure(state='normal')
        elif effect == "apply_glitch":
            self.glitch_slide.configure(state='normal')
        elif effect == "apply_pers":
            self.perspectivex_slide.configure(state='normal')
            self.perspectivey_slide.configure(state='normal')
        elif effect == "apply_dist":
            self.distortion_radius_slide.configure(state='normal')
            self.distortion_strength_slide.configure(state='normal')
        

    def disable_sliders(self):
        self.wavex_slide.configure(state='disabled')
        self.wavey_slide.configure(state='disabled')
        self.twist_strength_slide.configure(state='disabled')
        self.twist_radius_slide.configure(state='disabled')
        self.glitch_slide.configure(state='disabled')
        self.perspectivex_slide.configure(state='disabled')
        self.perspectivey_slide.configure(state='disabled')
        self.distortion_radius_slide.configure(state='disabled')
        self.distortion_strength_slide.configure(state='disabled')

