"""This module runs create account page."""


from customtkinter import CTkFrame, CTkEntry, CTkLabel, CTkButton
import customtkinter as ctk
from .Userfuncs import signupfunc, loginfunc

class SignupFrame(CTkFrame):
    """Create Account Page."""

    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Configure grid to expand
        self.pack(fill="both", expand=True)

        # Title
        CTkLabel(self, text="Create Account", font=("Arial", 24, "bold")).pack(pady=10)

        # Username Entry
        self.username_entry = CTkEntry(self, placeholder_text="Username")
        self.username_entry.pack(pady=5)

        # Password Entry
        self.password_entry = CTkEntry(self, placeholder_text="Password", show="*")
        self.password_entry.pack(pady=5)

        # Password confirmation
        self.password_confentry = CTkEntry(self, placeholder_text="Confirm Password", show="*")
        self.password_confentry.pack(pady=5)

        # Submit Button
        CTkButton(self, text="Create account", command=self.create_account).pack(pady=10)

        # Back Button
        import frames.LoginFrame as lf
        CTkButton(self, text="Back", command=lambda: controller.show_frame(lf.LoginFrame)).pack(pady=5)
    
    def create_account(self):
        """Signup"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        confpass = self.password_confentry.get()
        if signupfunc.create(username, password) and confpass == password:
            signupfunc.close_conncetion()
            import frames.CreateFrame as cf
            self.controller.show_frame(cf.CreateFrame)
        else:
            signupfunc.close_conncetion()
            error_window = ctk.CTkToplevel(self)
            error_window.title('Oops!')
            CTkLabel(error_window, text='Passwords do not match or this user already exists.')
            error_window.geometry('200x200')