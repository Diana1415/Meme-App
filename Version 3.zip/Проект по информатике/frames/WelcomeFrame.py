"""This module contains Welcome page."""

from customtkinter import CTkFrame, CTkLabel, CTkButton


class WelcomeFrame(CTkFrame):
    """First page (Welcome Page)."""

    def __init__(self, parent, controller):
        super().__init__(parent) # constructor to initialize atributes from the super class
        self.controller = controller  # save link to a parent frame

        # Configure grid to expand if size of window is changed
        self.pack(fill="both", expand=True)
        self.label1 = CTkLabel(self, text="Welcome to Meme Generator!", corner_radius=32)
        self.label1.pack(side='top')

        # Next button (to the login page)
        import frames.LoginFrame as lf
        self.btn1 = CTkButton(self, text="Next", command=lambda: controller.show_frame(lf.LoginFrame))
        self.btn1.pack(pady=10)