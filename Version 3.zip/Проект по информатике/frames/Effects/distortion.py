import cv2
import numpy as np
from PIL import Image

def distort_face(image_array, cx, cy, strength, radius):
    """Искажает часть изображения вокруг заданной точки"""

    h, w = image_array.shape[:2]
    
    # Создаём сетку координат
    y, x = np.indices((h, w), dtype=np.float32)
    dx, dy = x - cx, y - cy
    r = np.sqrt(dx**2 + dy**2)

    # Масштабируем искажение в зависимости от расстояния от центра
    factor = np.exp(-(r / radius)**2) * strength / 100
    x_new = np.clip(x + dx * factor, 0, w - 1)
    y_new = np.clip(y + dy * factor, 0, h - 1)

    # Применяем смещение
    distorted_img = cv2.remap(image_array, x_new.astype(np.float32), y_new.astype(np.float32), interpolation=cv2.INTER_LINEAR)

    return distorted_img

