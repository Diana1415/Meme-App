"""This module runs login page."""


from customtkinter import CTkFrame, CTkEntry, CTkLabel, CTkButton
import customtkinter as ctk
from .Userfuncs import loginfunc

class LoginFrame(CTkFrame):
    """Log In Page."""

    def __init__(self, parent, controller):
        super().__init__(parent)  # constructor to initialize atributes from the super class
        self.controller = controller  # save link to a parent frame

        # Configure grid to expand
        self.pack(fill="both", expand=True)

        # Title
        self.title1 = CTkLabel(self, text="Log In", font=("Arial", 24, "bold"))
        self.title1.pack(pady=10)

        # Username Entry
        self.username_entry = CTkEntry(self, placeholder_text="Username")
        self.username_entry.pack(pady=5)

        # Password Entry
        self.password_entry = CTkEntry(self, show="*", placeholder_text="Password")
        self.password_entry.pack(pady=5)

        # Submit Button
        CTkButton(self, text="Log In", command=self.login).pack(pady=10)

        # Create Account Button (используем controller.frames)
        import frames.SignupFrame as sf
        CTkButton(self, text="Create account", command=lambda: controller.show_frame(sf.SignupFrame)).pack(pady=5)

        # Forgot password Button (используем controller.frames)
        import frames.ForgotFrame as ff
        CTkButton(self, text="Forgot password?", command=lambda: controller.show_frame(ff.ForgotFrame)).pack(pady=5)

    def login(self):
        """Login Check."""
        username = self.username_entry.get()  # get username and pass
        password = self.password_entry.get()

        if loginfunc.verify(username, password):  # If login is verified
            loginfunc.close_conncetion()
            from frames.ChoiceFrame import ChoiceFrame
            self.controller.show_frame(ChoiceFrame)
        else:
            loginfunc.close_conncetion()
            error_window = ctk.CTkToplevel(self,)
            error_window.title('Oops!')
            CTkLabel(error_window, text='Wrong Username or Password').pack(anchor='center')
            error_window.geometry('200x200')
